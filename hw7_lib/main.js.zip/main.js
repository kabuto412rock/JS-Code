var _ = require('lodash')
var set = _.intersection([1, 3, 7, 9], [2, 3, 8, 9])
console.log('set=', set)
